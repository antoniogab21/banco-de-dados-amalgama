import { useState } from 'react';
import { motion } from 'motion/react';
import { Building2, Lock } from 'lucide-react';

interface LoginFormNewProps {
  onLogin: (companyId: string) => void;
  onSwitchToRegister: () => void;
}

export default function LoginFormNew({ onLogin, onSwitchToRegister }: LoginFormNewProps) {
  const [companyId, setCompanyId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (companyId.trim()) {
      onLogin(companyId);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-3xl mb-4 shadow-lg">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Amalgama</h1>
          <p className="text-gray-600">Compras Coletivas B2B</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Entrar na conta</h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="companyId" className="block text-sm font-semibold text-gray-700 mb-2">
                ID da Empresa
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="companyId"
                  type="text"
                  value={companyId}
                  onChange={(e) => setCompanyId(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 rounded-xl border-2 border-gray-200 focus:border-yellow-500 focus:ring-4 focus:ring-yellow-100 outline-none transition text-gray-900"
                  placeholder="Digite o ID da sua empresa"
                  required
                />
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-white font-bold py-4 rounded-xl transition shadow-lg hover:shadow-xl"
            >
              Entrar
            </motion.button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={onSwitchToRegister}
              className="text-gray-600 hover:text-yellow-600 font-semibold transition"
            >
              Criar novo ID
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
