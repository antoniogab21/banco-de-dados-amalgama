import { motion } from 'motion/react';
import { Building2, Mail, FileText, Edit2, Upload, Users } from 'lucide-react';
import SidebarNew from './SidebarNew';

interface CompanyProfileProps {
  userType: 'mercado' | 'fornecedor';
}

export default function CompanyProfile({ userType }: CompanyProfileProps) {
  return (
    <>
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Perfil da Empresa</h1>
            <p className="text-gray-600">Informações completas da sua empresa</p>
          </div>

          <div className="max-w-4xl">
            {/* Company Header Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-sm p-8 mb-6"
            >
              <div className="flex items-start gap-8">
                {/* Logo */}
                <div className="relative">
                  <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center shadow-lg">
                    <Building2 className="w-16 h-16 text-white" />
                  </div>
                  <button className="absolute bottom-0 right-0 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition">
                    <Upload className="w-5 h-5 text-gray-600" />
                  </button>
                </div>

                {/* Company Info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h2 className="text-3xl font-bold text-gray-900 mb-2">Minha Empresa LTDA</h2>
                      <div className="inline-block px-4 py-1.5 bg-yellow-100 text-yellow-700 rounded-full font-semibold text-sm">
                        {userType === 'mercado' ? 'Mercado' : 'Fornecedor'}
                      </div>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold px-6 py-3 rounded-xl transition"
                    >
                      <Edit2 className="w-4 h-4" />
                      Editar Perfil
                    </motion.button>
                  </div>

                  {/* Quick Stats */}
                  <div className="grid grid-cols-3 gap-4 mt-6">
                    <div className="bg-gray-50 rounded-xl p-4">
                      <p className="text-sm text-gray-500 mb-1">Desde</p>
                      <p className="font-bold text-gray-900">Janeiro 2024</p>
                    </div>
                    <div className="bg-gray-50 rounded-xl p-4">
                      <p className="text-sm text-gray-500 mb-1">
                        {userType === 'mercado' ? 'Pedidos Feitos' : 'Pedidos Recebidos'}
                      </p>
                      <p className="font-bold text-gray-900">65</p>
                    </div>
                    <div className="bg-gray-50 rounded-xl p-4">
                      <p className="text-sm text-gray-500 mb-1">Grupos</p>
                      <p className="font-bold text-gray-900">3</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Detailed Information */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-2xl shadow-sm p-8 mb-6"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-6">Informações da Empresa</h3>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-500 mb-2">
                    Nome da Empresa
                  </label>
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-gray-50">
                    <Building2 className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-900 font-semibold">Minha Empresa LTDA</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-500 mb-2">
                    CNPJ
                  </label>
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-gray-50">
                    <FileText className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-900 font-semibold">00.000.000/0000-00</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-500 mb-2">
                    Email Corporativo
                  </label>
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-gray-50">
                    <Mail className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-900 font-semibold">contato@minhaempresa.com</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-500 mb-2">
                    Telefone
                  </label>
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-gray-50">
                    <span className="text-gray-900 font-semibold">(11) 98765-4321</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-500 mb-2">
                    Endereço
                  </label>
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-gray-50">
                    <span className="text-gray-900 font-semibold">
                      Rua Exemplo, 123 - São Paulo, SP - CEP 01234-567
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Companies Registered (for suppliers) */}
            {userType === 'fornecedor' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-2xl shadow-sm p-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <Users className="w-6 h-6 text-yellow-600" />
                    <h3 className="text-xl font-bold text-gray-900">Empresas Cadastradas</h3>
                  </div>
                  <span className="bg-yellow-100 text-yellow-700 font-bold px-4 py-2 rounded-full">
                    24 empresas
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {[
                    'Mercado Central',
                    'Empório São José',
                    'Supermercado Bom Preço',
                    'Mini Mercado Silva',
                    'Padaria Pão Quente',
                    'Mercearia do João',
                  ].map((company, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-4 rounded-xl bg-gray-50 hover:bg-gray-100 transition">
                      <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-yellow-600" />
                      </div>
                      <span className="font-medium text-gray-900">{company}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
