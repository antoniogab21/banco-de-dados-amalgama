import { motion } from 'motion/react';
import {
  LayoutDashboard,
  MessageSquare,
  ShoppingCart,
  Package,
  CreditCard,
  User,
  Settings,
  Building2,
  LogOut
} from 'lucide-react';

interface SidebarNewProps {
  userType: 'mercado' | 'fornecedor';
  activePage: string;
  onNavigate?: (page: string) => void;
}

export default function SidebarNew({ userType, activePage, onNavigate }: SidebarNewProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'feed', label: 'Feed de Grupos', icon: MessageSquare },
    { id: 'pedidos', label: 'Pedidos', icon: ShoppingCart },
    { id: 'produtos', label: 'Produtos', icon: Package },
    { id: 'pagamentos', label: 'Pagamentos', icon: CreditCard },
    { id: 'perfil', label: 'Perfil', icon: User },
    { id: 'configuracoes', label: 'Configurações', icon: Settings },
  ];

  return (
    <div className="w-72 bg-white border-r border-gray-200 flex flex-col">
      {/* Logo & Company */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center shadow-lg">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Amalgama</h3>
            <p className="text-xs text-gray-500 capitalize">{userType}</p>
          </div>
        </div>
        <div className="bg-gray-50 rounded-xl p-3">
          <p className="text-xs text-gray-500 mb-1">Empresa</p>
          <p className="font-semibold text-gray-900 text-sm">Minha Empresa</p>
        </div>
      </div>

      {/* Menu */}
      <nav className="flex-1 p-4">
        <div className="space-y-1">
          {menuItems.map((item) => {
            const isActive = activePage === item.id;
            return (
              <motion.button
                key={item.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onNavigate?.(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition ${
                  isActive
                    ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-white shadow-lg'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-semibold">{item.label}</span>
              </motion.button>
            );
          })}
        </div>
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-gray-200">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-semibold">Sair</span>
        </motion.button>
      </div>
    </div>
  );
}
