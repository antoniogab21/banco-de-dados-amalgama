import { motion } from 'motion/react';
import { Package, Edit2, Trash2, Plus } from 'lucide-react';
import SidebarNew from './SidebarNew';

interface SupplierProductsPageProps {
  userType: 'mercado' | 'fornecedor';
}

export default function SupplierProductsPage({ userType }: SupplierProductsPageProps) {
  const products = [
    {
      id: 1,
      name: 'Arroz Tipo 1 - 5kg',
      description: 'Arroz branco tipo 1, pacote de 5kg',
      price: 22.90,
      stock: 500,
      sold: 450,
      image: '🌾',
    },
    {
      id: 2,
      name: 'Feijão Preto - 1kg',
      description: 'Feijão preto premium',
      price: 6.90,
      stock: 300,
      sold: 380,
      image: '🫘',
    },
    {
      id: 3,
      name: 'Óleo de Soja - 900ml',
      description: 'Óleo de soja refinado',
      price: 5.90,
      stock: 200,
      sold: 290,
      image: '🧴',
    },
    {
      id: 4,
      name: 'Açúcar Cristal - 1kg',
      description: 'Açúcar cristal puro',
      price: 3.30,
      stock: 400,
      sold: 210,
      image: '🍬',
    },
    {
      id: 5,
      name: 'Café Torrado - 500g',
      description: 'Café torrado e moído',
      price: 14.90,
      stock: 150,
      sold: 180,
      image: '☕',
    },
    {
      id: 6,
      name: 'Macarrão Espaguete - 500g',
      description: 'Macarrão espaguete',
      price: 3.60,
      stock: 600,
      sold: 320,
      image: '🍝',
    },
  ];

  return (
    <>
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Meu Catálogo</h1>
              <p className="text-gray-600">Gerencie seus produtos disponíveis</p>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-white font-bold px-6 py-3 rounded-xl shadow-lg"
            >
              <Plus className="w-5 h-5" />
              Adicionar Produto
            </motion.button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <p className="text-sm text-gray-500 mb-1">Total de Produtos</p>
              <p className="text-3xl font-bold text-gray-900">{products.length}</p>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <p className="text-sm text-gray-500 mb-1">Estoque Total</p>
              <p className="text-3xl font-bold text-gray-900">2,150 un.</p>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <p className="text-sm text-gray-500 mb-1">Vendidos este Mês</p>
              <p className="text-3xl font-bold text-yellow-600">1,830 un.</p>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-sm hover:shadow-md transition overflow-hidden group"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="text-5xl">{product.image}</div>
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition opacity-0 group-hover:opacity-100">
                        <Edit2 className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition opacity-0 group-hover:opacity-100">
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-gray-900 text-lg mb-2">{product.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{product.description}</p>

                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Preço</span>
                      <span className="font-bold text-yellow-600 text-xl">
                        R$ {product.price.toFixed(2)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Estoque</span>
                      <span className={`font-semibold ${
                        product.stock < 200 ? 'text-red-600' : 'text-green-600'
                      }`}>
                        {product.stock} un.
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Vendidos</span>
                      <span className="font-semibold text-gray-900">{product.sold} un.</span>
                    </div>
                  </div>

                  {/* Stock Progress */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-500">Disponibilidade</span>
                      <span className="text-xs text-gray-600">
                        {Math.round((product.stock / (product.stock + product.sold)) * 100)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-yellow-400 to-yellow-500 h-2 rounded-full"
                        style={{ width: `${(product.stock / (product.stock + product.sold)) * 100}%` }}
                      />
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 rounded-xl transition"
                  >
                    Editar Produto
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
